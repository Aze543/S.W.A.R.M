import { useFocusEffect } from "expo-router";
import * as ScreenOrientation from "expo-screen-orientation";
import { StatusBar } from "expo-status-bar";
import { useCallback, useEffect, useRef, useState } from "react";
import { Pressable, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

type Mode = "autonomous" | "manual";
type Command = "FORWARD" | "STOP" | "LEFT" | "RIGHT";

const BASE_URL = process.env.EXPO_PUBLIC_PI_URL ?? "http://192.168.1.100:5000";

// Re-send held command every 300 ms so at least one lands
// per Arduino scan cycle (~2-3 s). Fire-and-forget — no awaiting.
const REPEAT_MS = 300;

// Simple fire-and-forget POST — sends command as JSON body
function fireCommand(command: Command) {
  fetch(`${BASE_URL}/control`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ command }),
  }).catch((e) => console.warn("[CTRL]", command, e));
}

async function disableAutonomous() {
  try {
    await fetch(`${BASE_URL}/mission`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "stop" }),
    });
  } catch (e) {
    console.warn("[CTRL] Failed to stop mission", e);
  }
  fireCommand("STOP");
}

export default function Controller() {
  const [mode, setMode] = useState<Mode>("autonomous");
  const [activeCmd, setActiveCmd] = useState<Command | null>(null);
  const [boost, setBoost] = useState(false);
  const [horn, setHorn] = useState(false);

  const repeatRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useFocusEffect(
    useCallback(() => {
      ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.LANDSCAPE);
      return () => {
        stopRepeat();
        fireCommand("STOP");
        ScreenOrientation.lockAsync(ScreenOrientation.OrientationLock.PORTRAIT_UP);
      };
    }, [])
  );

  useEffect(() => () => stopRepeat(), []);

  function stopRepeat() {
    if (repeatRef.current) {
      clearInterval(repeatRef.current);
      repeatRef.current = null;
    }
  }

  // Press: send immediately + start repeating every REPEAT_MS
  function handlePressIn(cmd: Command) {
    if (!isManual) return;
    setActiveCmd(cmd);
    fireCommand(cmd);                                         // immediate
    stopRepeat();
    repeatRef.current = setInterval(() => fireCommand(cmd), REPEAT_MS); // repeat
  }

  // Release: stop repeating, send STOP once
  function handlePressOut() {
    stopRepeat();
    setActiveCmd(null);
    fireCommand("STOP");
  }

  const isManual = mode === "manual";

  const dpadBtn = (cmd: Command) =>
    `w-20 h-20 rounded-2xl items-center justify-center border-2 ${
      activeCmd === cmd && isManual
        ? "bg-blue-500 border-blue-300"
        : isManual
        ? "bg-slate-800 border-slate-600"
        : "bg-slate-800/40 border-slate-700 opacity-30"
    }`;

  const throttleLabel =
    activeCmd === "FORWARD" ? "FORWARD" :
    activeCmd === "STOP"    ? "STOPPING" : "IDLE";

  const steerLabel =
    activeCmd === "LEFT"  ? "LEFT"  :
    activeCmd === "RIGHT" ? "RIGHT" : "CENTER";

  return (
    <SafeAreaView className="flex-1 bg-slate-900" edges={["top", "bottom", "left", "right"]}>
      <StatusBar style="light" hidden />

      {/* ── Top Bar ── */}
      <View className="flex-row items-center justify-between px-5 pt-3 pb-2">
        <Text className="text-white text-base font-bold tracking-widest">CONTROLLER</Text>

        <View className="flex-row bg-slate-800 rounded-xl p-1">
          <Pressable
            onPress={() => { setMode("autonomous"); handlePressOut(); }}
            className={`px-5 py-2 rounded-lg items-center ${mode === "autonomous" ? "bg-blue-600" : ""}`}
          >
            <Text className="text-white font-semibold text-xs tracking-wider">AUTONOMOUS</Text>
          </Pressable>
          <Pressable
            onPress={() => {setMode("manual");disableAutonomous();}}
            className={`px-5 py-2 rounded-lg items-center ${mode === "manual" ? "bg-blue-600" : ""}`}
          >
            <Text className="text-white font-semibold text-xs tracking-wider">MANUAL</Text>
          </Pressable>
        </View>

        <View className={`px-3 py-1 rounded-full ${isManual ? "bg-blue-600/30" : "bg-green-600/30"}`}>
          <Text className={`text-xs font-bold ${isManual ? "text-blue-400" : "text-green-400"}`}>
            {isManual ? "● MANUAL" : "● AUTO"}
          </Text>
        </View>
      </View>

      {/* ── Main Control Area ── */}
      <View className="flex-1 flex-row items-center px-6 gap-6">

        {/* ── Left D-Pad: Throttle ── */}
        <View className="flex-1 items-center justify-center gap-3">
          <Text className="text-gray-500 text-xs tracking-widest">THROTTLE</Text>

          <Pressable
            onPressIn={() => handlePressIn("FORWARD")}
            onPressOut={handlePressOut}
            disabled={!isManual}
            className={dpadBtn("FORWARD")}
          >
            <Text className="text-white text-3xl leading-none">▲</Text>
            <Text className="text-gray-400 text-xs mt-1">FWD</Text>
          </Pressable>

          <View className="w-20 h-8 rounded-lg items-center justify-center bg-slate-800/60 border border-slate-700">
            <Text className="text-gray-500 text-xs">{isManual ? throttleLabel : "—"}</Text>
          </View>

          <Pressable
            onPressIn={() => handlePressIn("STOP")}
            onPressOut={handlePressOut}
            disabled={!isManual}
            className={dpadBtn("STOP")}
          >
            <Text className="text-white text-3xl leading-none">▼</Text>
            <Text className="text-gray-400 text-xs mt-1">STOP</Text>
          </Pressable>
        </View>

        {/* ── Center: Telemetry + Actions ── */}
        <View className="items-center gap-3" style={{ width: 160 }}>
          <View className="bg-slate-800 rounded-xl px-4 py-3 w-full">
            <View className="flex-row justify-between mb-2">
              <Text className="text-gray-500 text-xs">THROTTLE</Text>
              <Text className={`text-xs font-bold ${activeCmd === "FORWARD" ? "text-blue-400" : "text-white"}`}>
                {isManual ? throttleLabel : "AUTO"}
              </Text>
            </View>
            <View className="flex-row justify-between">
              <Text className="text-gray-500 text-xs">STEER</Text>
              <Text className={`text-xs font-bold ${activeCmd === "LEFT" || activeCmd === "RIGHT" ? "text-blue-400" : "text-white"}`}>
                {isManual ? steerLabel : "AUTO"}
              </Text>
            </View>
          </View>

          <View className="flex-row gap-3 w-full">
            <Pressable
              onPressIn={() => setBoost(true)}
              onPressOut={() => setBoost(false)}
              disabled={!isManual}
              className={`flex-1 rounded-xl py-4 items-center border ${
                boost && isManual ? "bg-yellow-500 border-yellow-400"
                : isManual ? "bg-slate-800 border-slate-600"
                : "bg-slate-800/40 border-slate-700 opacity-40"
              }`}
            >
              <Text className="text-lg">⚡</Text>
              <Text className={`text-xs font-bold mt-1 ${boost && isManual ? "text-yellow-900" : "text-gray-400"}`}>BOOST</Text>
            </Pressable>

            <Pressable
              onPressIn={() => setHorn(true)}
              onPressOut={() => setHorn(false)}
              disabled={!isManual}
              className={`flex-1 rounded-xl py-4 items-center border ${
                horn && isManual ? "bg-orange-500 border-orange-400"
                : isManual ? "bg-slate-800 border-slate-600"
                : "bg-slate-800/40 border-slate-700 opacity-40"
              }`}
            >
              <Text className="text-lg">📢</Text>
              <Text className={`text-xs font-bold mt-1 ${horn && isManual ? "text-orange-100" : "text-gray-400"}`}>HORN</Text>
            </Pressable>
          </View>

          <Pressable
            onPress={() => { if (isManual) { stopRepeat(); setActiveCmd(null); fireCommand("STOP"); } }}
            disabled={!isManual}
            className={`w-full rounded-xl py-4 items-center border ${
              isManual ? "bg-red-600/20 border-red-500 active:bg-red-600/40"
              : "bg-slate-800/40 border-slate-700 opacity-30"
            }`}
          >
            <Text className={`font-bold text-sm tracking-widest ${isManual ? "text-red-400" : "text-gray-500"}`}>
              ■ E-STOP
            </Text>
          </Pressable>
        </View>

        {/* ── Right D-Pad: Steering ── */}
        <View className="flex-1 items-center justify-center gap-3">
          <Text className="text-gray-500 text-xs tracking-widest">STEERING</Text>

          <View className="w-20 h-20" />

          <View className="flex-row items-center gap-3">
            <Pressable
              onPressIn={() => handlePressIn("LEFT")}
              onPressOut={handlePressOut}
              disabled={!isManual}
              className={dpadBtn("LEFT")}
            >
              <Text className="text-white text-3xl leading-none">◄</Text>
              <Text className="text-gray-400 text-xs mt-1">LEFT</Text>
            </Pressable>

            <View className="w-12 h-12 rounded-xl items-center justify-center bg-slate-800/60 border border-slate-700">
              <View className={`w-4 h-4 rounded-full ${activeCmd === "LEFT" || activeCmd === "RIGHT" ? "bg-blue-500" : "bg-slate-600"}`} />
            </View>

            <Pressable
              onPressIn={() => handlePressIn("RIGHT")}
              onPressOut={handlePressOut}
              disabled={!isManual}
              className={dpadBtn("RIGHT")}
            >
              <Text className="text-white text-3xl leading-none">►</Text>
              <Text className="text-gray-400 text-xs mt-1">RIGHT</Text>
            </Pressable>
          </View>

          <View className="w-20 h-20" />

          <Text className="text-gray-400 text-xs">
            {isManual ? steerLabel : "DISABLED"}
          </Text>
        </View>

      </View>

      {!isManual && (
        <View className="absolute bottom-6 left-0 right-0 items-center">
          <View className="bg-green-900/50 border border-green-700 rounded-full px-5 py-2">
            <Text className="text-green-400 text-xs font-semibold tracking-widest">
              AUTONOMOUS MODE ACTIVE — CONTROLS LOCKED
            </Text>
          </View>
        </View>
      )}
    </SafeAreaView>
  );
}